import json
import os
import boto3
import uuid
from datetime import datetime, timezone

s3_client = boto3.client('s3')
BUCKET_NAME = os.environ.get('BUCKET_NAME', 'your-s3-bucket-name')

def lambda_handler(event, context):
    # Handle CORS preflight requests
    if event.get('httpMethod') == 'OPTIONS' or event.get('requestContext', {}).get('http', {}).get('method') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            },
            'body': ''
        }

    try:
        # Parse incoming JSON body
        body = json.loads(event.get('body', '{}'))
        filename = body.get('filename')
        file_size = body.get('file_size')
        uploader_name = body.get('uploader_name')
        uploader_email = body.get('uploader_email')
        message = body.get('message', '')
        content_type = body.get('content_type', 'application/octet-stream')

        if not filename or not uploader_email or not uploader_name:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Missing required fields: filename, uploader_name, uploader_email'})
            }

        # Generate unique submission ID and S3 paths
        submission_id = f"sub_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:6]}"
        file_key = f"uploads/{submission_id}/{filename}"
        metadata_key = f"uploads/{submission_id}/metadata.json"

        # Create metadata structure
        metadata = {
            "submission_id": submission_id,
            "uploader_name": uploader_name,
            "uploader_email": uploader_email,
            "message": message,
            "original_filename": filename,
            "file_size": file_size,
            "upload_timestamp": datetime.now(timezone.utc).isoformat(),
            "status": "pending"
        }

        # Write metadata.json to S3
        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=metadata_key,
            Body=json.dumps(metadata, indent=2),
            ContentType='application/json'
        )

        # Generate presigned PUT URL valid for 5 minutes (300 seconds)
        presigned_url = s3_client.generate_presigned_url(
            'put_object',
            Params={
                'Bucket': BUCKET_NAME,
                'Key': file_key,
                'ContentType': content_type
            },
            ExpiresIn=300
        )

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'submission_id': submission_id,
                'upload_url': presigned_url,
                'file_key': file_key
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': str(e)})
        }